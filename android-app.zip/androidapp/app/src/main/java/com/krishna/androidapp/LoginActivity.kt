package com.krishna.androidapp

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class LoginActivity : AppCompatActivity() {

    lateinit var etMobileNumber: EditText
    lateinit var etPassword: EditText
    lateinit var btnLogin: Button
    lateinit var txtForgotPassword: TextView
    lateinit var txtRegister: TextView

    lateinit var sharedPreferences: SharedPreferences


    val validmobilenumber = "8130987054"
    val validpassword = arrayOf("ganga", "jamuna", "saraswati", "rapti", "satlej")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        sharedPreferences =
            getSharedPreferences(getString(R.string.preference_file_name), Context.MODE_PRIVATE)

        val isloggedin = sharedPreferences.getBoolean("isLoggedIn", false)

        if (isloggedin) {
            val intent = Intent(this@LoginActivity, MainActivity::class.java)
            startActivity(intent)
        } else {
            setContentView(R.layout.login_activity)
        }

        setContentView(R.layout.login_activity)

        title = "LOG IN"
        etMobileNumber = findViewById(R.id.etMobileNumber)
        etPassword = findViewById(R.id.etPassword)
        btnLogin = findViewById(R.id.btnButton)
        txtForgotPassword = findViewById(R.id.txtForgotPassword)
        txtRegister = findViewById(R.id.txtRegisterYourself)
        btnLogin.setOnClickListener {
            val mobilenumber = etMobileNumber.text.toString()
            val password = etPassword.text.toString()
            var nameofavenger = "HELLO AVENGER"

            if ((mobilenumber == validmobilenumber)) {
                val intent = Intent(this@LoginActivity, MainActivity::class.java)
                if (password == validpassword[0]) {
                    nameofavenger = "HELLO GANGA"
                    savepreferences(nameofavenger)
                    startActivity(intent)

                } else if (password == validpassword[1]) {
                    savepreferences(nameofavenger)
                    nameofavenger = "HELLO JAMUNA"
                    startActivity(intent)
                } else if (password == validpassword[2]) {
                    nameofavenger = "HELLO SARASWATI"
                    savepreferences(nameofavenger)
                    startActivity(intent)
                } else if ((validpassword.contains(password))) {
                    savepreferences(nameofavenger)
                    startActivity(intent)
                } else {
                    Toast.makeText(
                        this@LoginActivity,
                        "Mobile Number or Password is Incorrect !",

                        Toast.LENGTH_LONG
                    ).show()

                }
            } else {
                Toast.makeText(
                    this@LoginActivity,
                    "Mobile Number or Password is Incorrect !",
                    Toast.LENGTH_LONG
                ).show()

            }
        }

    }


    override fun onPause() {
        super.onPause()
        finish()
    }

    fun savepreferences(title:String) {
        sharedPreferences.edit().putBoolean("isLoggedIn", true).apply()
        sharedPreferences.edit().putString("Title",title).apply()


    }

}